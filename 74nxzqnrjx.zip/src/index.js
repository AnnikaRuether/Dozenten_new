import React from "react";
import { render } from "react-dom";
import Dozenten from "./components/dozenten.js";
import "./styles.css";

export default class App extends React.Component {
  render() {
    return (
      <div className="App">
        <h1>Die Dozenten vom Studiengang Informationsmanagement</h1>
        <Dozenten />
      </div>
    );
  }
}

render(<App />, document.getElementById("root"));
