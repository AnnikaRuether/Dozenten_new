import React from "react";
import { render } from "react-dom";

export default class Beschreibung extends React.Component {
  render() {
    return (
      <div className="Beschreibung">
        {this.props.name}
        {this.props.lehrgebiete}
        {this.props.arbeitsgebiete}
        {this.props.aug}
      </div>
    );
  }
}
