import React from "react";
import "../styles.css";
import dozenten from "../dozenten.json";
import Beschreibung from "./beschreibung.js";

export default class Dozenten extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showComponent: false,
      name: "test",
      lehrgebiete: "test",
      arbeitsgebiete: "test",
      aug: "test"
    };
    this.Klick1 = this.Klick1.bind(this);
  }

  Klick1(name, lehrgebiete, arbeitsgebiete, aug) {
    this.setState({
      showComponent: true,
      name: name,
      lehrgebiete: lehrgebiete,
      arbeitsgebiete: arbeitsgebiete,
      aug: aug
    });
  }

  render() {
    return (
      <div className="Text">
        <div className="Beschreibung">
          {this.state.showComponent ? (
            <Beschreibung name={this.state.name} />
          ) : null}
          {this.state.showComponent ? (
            <Beschreibung lehrgebiete={this.state.lehrgebiete} />
          ) : null}
          {this.state.showComponent ? (
            <Beschreibung arbeitsgebiete={this.state.arbeitsgebiete} />
          ) : null}
          {this.state.showComponent ? (
            <Beschreibung aug={this.state.aug} />
          ) : null}
        </div>
        <div className="Dozenten">
          {dozenten.map(dozenten => (
            <div className="einzelbild">
              <button
                class="Same"
                onClick={() =>
                  this.Klick1(
                    dozenten.name,
                    dozenten.lehrgebiete,
                    dozenten.arbeitsgebiete,
                    dozenten.aug
                  )
                }
              >
                {" "}
                <img src={dozenten.image} className="Galerie" />
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }
}
